#' @importFrom methods new show slot slotNames validObject
#' @importFrom utils browseURL globalVariables install.packages
#'     installed.packages update.packages
#' @importFrom rmarkdown render
#' @importFrom readODS read_ods
#' @importFrom DBI dbConnect
#' @importFrom tcltk tclVar tclvalue tkbind tkbutton tkdestroy tkentry tkfocus
#'     tkgrid tkgrid.configure tklabel tktoplevel tkwait.window tkwm.title
#' 
NULL
