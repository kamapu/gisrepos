#' @importFrom utils browseURL globalVariables install.packages
#'     installed.packages update.packages
#' @importFrom rmarkdown render
#' @importFrom readODS read_ods
#' @importFrom RPostgres dbConnect
#' @importFrom RPostgreSQL dbConnect
#' @importFrom tcltk tclVar tclvalue tkbind tkbutton tkdestroy tkentry tkfocus
#'     tkgrid tkgrid.configure tklabel tktoplevel tkwait.window tkwm.title
#' 
NULL
