#' @importFrom methods new show slot slotNames validObject
#' @importFrom utils browseURL globalVariables install.packages
#'     installed.packages update.packages
#' 
NULL
